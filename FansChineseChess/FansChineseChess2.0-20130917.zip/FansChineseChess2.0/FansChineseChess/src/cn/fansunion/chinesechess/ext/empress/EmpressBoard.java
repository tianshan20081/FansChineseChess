/**
 * ��Ŀ����: FansChineseChess
 * �汾�ţ�2.0
 * ���֣�����
 * ����: http://FansUnion.cn
 * CSDN:http://blog.csdn.net/FansUnion
 * ����: leiwen@FansUnion.cn
 * QQ��240-370-818
 * ��Ȩ����: 2011-2013,leiwen
 */
package cn.fansunion.chinesechess.ext.empress;

import java.awt.Color;
import java.awt.event.MouseAdapter;

import cn.fansunion.chinesechess.ColorUtil;
import cn.fansunion.chinesechess.core.ChessBoard;


/**
 * N�ʺ�����
 * 
 * @author leiwen@fansunion.cn,http://FansUnion.cn,
 *         http://blog.csdn.net/FansUnion
 * @since 2.0
 */
public class EmpressBoard extends ChessBoard {

	private static final long serialVersionUID = 4499247593357571375L;

	@Override
	protected Color getBackgroundColor() {
		return ColorUtil.getEmpressBgcolor();
	}

	@Override
	protected MouseAdapter getMouseAdapter() {
		return null;
	}

	@Override
	protected BoardType getBoardType() {
		return BoardType.eightEmpress;
	}

}
