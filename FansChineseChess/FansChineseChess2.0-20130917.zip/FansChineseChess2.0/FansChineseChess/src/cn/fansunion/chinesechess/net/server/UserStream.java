/**
 * ��Ŀ����: FansChineseChess
 * �汾�ţ�2.0
 * ���֣�����
 * ����: http://FansUnion.cn
 * CSDN:http://blog.csdn.net/FansUnion
 * ����: leiwen@FansUnion.cn
 * QQ��240-370-818
 * ��Ȩ����: 2011-2013,leiwen
 */
package cn.fansunion.chinesechess.net.server;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * ���û��Ͷ�Ӧ���׽��֡������������
 * 
 * @author leiwen@fansunion.cn,http://FansUnion.cn,
 *         http://blog.csdn.net/FansUnion
 * @since 2.0
 */
public class UserStream {
	private String name;

	private Socket socket;

	private ObjectOutputStream oos;

	private ObjectInputStream ois;

	public UserStream() {

	}

	public UserStream(String name, ObjectOutputStream oos,
			ObjectInputStream ois, Socket socket) {
		this.name = name;
		this.oos = oos;
		this.ois = ois;
		this.socket = socket;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ObjectInputStream getOis() {
		return ois;
	}

	public void setOis(ObjectInputStream ois) {
		this.ois = ois;
	}

	public ObjectOutputStream getOos() {
		return oos;
	}

	public void setOos(ObjectOutputStream oos) {
		this.oos = oos;
	}

	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}
}
