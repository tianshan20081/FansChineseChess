/**
 * ��Ŀ����: FansChineseChess
 * �汾�ţ�2.0
 * ���֣�����
 * ����: http://FansUnion.cn
 * CSDN:http://blog.csdn.net/FansUnion
 * ����: leiwen@FansUnion.cn
 * QQ��240-370-818
 * ��Ȩ����: 2011-2013,leiwen
 */
package cn.fansunion.chinesechess;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import cn.fansunion.chinesechess.ai.ManMachineGUI;
import cn.fansunion.chinesechess.config.NAME;
import cn.fansunion.chinesechess.core.ManualUtil;
import cn.fansunion.chinesechess.ext.empress.EmpressGUI;
import cn.fansunion.chinesechess.ext.maze.HorseMazeGUI;
import cn.fansunion.chinesechess.load.ChessDemoGUI;
import cn.fansunion.chinesechess.load.ChessLoadingGUI;
import cn.fansunion.chinesechess.net.client.RoomGUI;
import cn.fansunion.chinesechess.print.all.PrintAllGUI;
import cn.fansunion.chinesechess.print.part.PrintPartGUI;
import cn.fansunion.chinesechess.save.GameRecord;


/**
 * �ͻ��������棬����������Ϸ��������ս����ѡ�
 * 
 * ������Ϸѡ�: ȫ�ִ��ף��оִ��ף�װ����Ϸ���߼�װ�أ��˻����ģ��Թ���⣬�˻ʺ� ������սѡ��� �����û���������ͷ�������ַ��¼������
 * 
 * @author leiwen@fansunion.cn,http://FansUnion.cn,
 *         http://blog.csdn.net/FansUnion
 * @since 2.0
 */
public class ChessGUI extends JFrame implements ActionListener, NAME {

	private static final long serialVersionUID = -4285888351596327876L;

	private JTabbedPane tabbedPane;

	private JPanel networkPanel;

	private JPanel localPanel;

	private JLabel petName = new JLabel("�û���:  ");

	private JLabel password = new JLabel("��  ��:  ");

	private JTextField petNameField = new JTextField(20);

	private JTextField passwordField = new JTextField(20);

	private JLabel serverIP = new JLabel("������IP:");

	private JTextField serverIPField = new JTextField(20);

	private JButton login, exit;

	private JButton load, loadAs, partialManual, wholeManual, manMachine, fen,
			maze, eightEmpress;

	public ChessGUI() {
		initButtons();
		initPanels();

		serverIPField.setText("localhost");
		setTitle("�������--����-http://FansUnion.cn");
		setIconImage(ChessUtil.getAppIcon());
		setSize(370, 340);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setResizable(false);

		// serverIPField.setText("localhost");
	}

	private void initButtons() {
		int w = ChessUtil.getImageIcon("login.png").getIconWidth()+10;
		int h = ChessUtil.getImageIcon("login.png").getIconHeight();
		login = new JButton("��¼");
		login.addActionListener(this);
		login.setToolTipText("��¼");
		login.setCursor(new Cursor(Cursor.HAND_CURSOR));
		login.setPreferredSize(new Dimension(w, h));

		exit = new JButton("�˳�");
		exit.addActionListener(this);
		exit.setToolTipText("�˳�");
		exit.setCursor(new Cursor(Cursor.HAND_CURSOR));
		exit.setPreferredSize(new Dimension(w, h));

		int width = ChessUtil.getImageIcon("load.png").getIconWidth()+10;
		int height = ChessUtil.getImageIcon("load.png").getIconHeight();

		load = new JButton("װ����Ϸ");
		load.addActionListener(this);
		load.setToolTipText("װ����Ϸ");
		load.setCursor(new Cursor(Cursor.HAND_CURSOR));
		load.setPreferredSize(new Dimension(width, height));

		loadAs = new JButton("�߼�װ��");
		loadAs.addActionListener(this);
		loadAs.setToolTipText("�߼�װ��");
		loadAs.setCursor(new Cursor(Cursor.HAND_CURSOR));
		loadAs.setPreferredSize(new Dimension(width, height));

		fen = new JButton("FEN�������");
		fen.addActionListener(this);
		fen.setToolTipText("����FEN���������");
		fen.setCursor(new Cursor(Cursor.HAND_CURSOR));
		fen.setPreferredSize(new Dimension(width + 20, height));

		partialManual = new JButton("�оִ���");
		partialManual.addActionListener(this);
		partialManual.setToolTipText("�оִ���");
		partialManual.setCursor(new Cursor(Cursor.HAND_CURSOR));
		partialManual.setPreferredSize(new Dimension(width, height));

		wholeManual = new JButton("ȫ�ִ���");
		wholeManual.addActionListener(this);
		wholeManual.setToolTipText("ȫ�ִ���");
		wholeManual.setCursor(new Cursor(Cursor.HAND_CURSOR));
		wholeManual.setPreferredSize(new Dimension(width, height));

		manMachine = new JButton("�˻�����");
		manMachine.addActionListener(this);
		manMachine.setToolTipText("�˻�����");
		manMachine.setCursor(new Cursor(Cursor.HAND_CURSOR));
		manMachine.setPreferredSize(new Dimension(width, height));

		maze = new JButton("�Թ����");
		maze.addActionListener(this);
		maze.setToolTipText("�Թ����");
		maze.setCursor(new Cursor(Cursor.HAND_CURSOR));
		maze.setPreferredSize(new Dimension(width, height));

		eightEmpress = new JButton("�˻ʺ�");
		eightEmpress.addActionListener(this);
		eightEmpress.setToolTipText("�˻ʺ�");
		eightEmpress.setCursor(new Cursor(Cursor.HAND_CURSOR));
		eightEmpress.setPreferredSize(new Dimension(width, height));

		/*
		 * moneyCollect = new JButton("Ǯ���ռ�");
		 * moneyCollect.addActionListener(this);
		 * moneyCollect.setToolTipText("Ǯ���ռ�"); moneyCollect.setCursor(new
		 * Cursor(Cursor.HAND_CURSOR)); moneyCollect.setPreferredSize(new
		 * Dimension(width, height));
		 */
	}

	private void initPanels() {
		TitledBorder oneBorder = new TitledBorder("�������");
		oneBorder.setTitleFont(new Font("����", Font.PLAIN, 16));
		oneBorder.setTitleColor(new Color(0, 0, 255));

		TitledBorder twoBorder = new TitledBorder("װ������");
		twoBorder.setTitleFont(new Font("����", Font.PLAIN, 16));
		twoBorder.setTitleColor(new Color(26, 151, 34));

		TitledBorder threeBorder = new TitledBorder("�˹�����");
		threeBorder.setTitleFont(new Font("����", Font.PLAIN, 16));
		threeBorder.setTitleColor(new Color(255, 0, 0));

		TitledBorder fourBorder = new TitledBorder("��չӦ��");
		fourBorder.setTitleFont(new Font("����", Font.PLAIN, 16));
		fourBorder.setTitleColor(new Color(128, 128, 0));

		// �����������
		FlowLayout flow = new FlowLayout(FlowLayout.LEFT);
		JPanel one = new JPanel(flow);
		one.setBorder(oneBorder);
		JPanel two = new JPanel(flow);
		two.setBorder(twoBorder);
		JPanel three = new JPanel(flow);
		three.setBorder(threeBorder);
		JPanel four = new JPanel(flow);
		four.setBorder(fourBorder);

		one.add(wholeManual);
		one.add(partialManual);
		one.add(fen);

		two.add(load);
		two.add(loadAs);

		four.add(maze);
		four.add(eightEmpress);
		// four.add(moneyCollect);

		three.add(manMachine);
		// three.add(exit);

		localPanel = new JPanel(new GridLayout(4, 3));
		localPanel.add(one);
		localPanel.add(two);
		localPanel.add(three);
		localPanel.add(four);

		// ������ս���
		FlowLayout flow2 = new FlowLayout(FlowLayout.LEFT);
		JPanel one2 = new JPanel(flow2);
		JPanel two2 = new JPanel(flow2);
		JPanel three2 = new JPanel(flow2);
		JPanel four2 = new JPanel(flow2);

		one2.add(petName);
		one2.add(petNameField);

		two2.add(password);
		two2.add(passwordField);

		three2.add(serverIP);
		three2.add(serverIPField);
		four2.add(login);
		four2.add(exit);

		networkPanel = new JPanel(new GridLayout(4, 2));
		networkPanel.add(one2);
		networkPanel.add(two2);
		networkPanel.add(three2);
		networkPanel.add(four2);
		tabbedPane = new JTabbedPane();
		tabbedPane.addTab("��������", ChessUtil.getImageIcon("hongshuai.gif"),
				localPanel, "�������У������");
		tabbedPane.addTab("������ս", ChessUtil.getImageIcon("heijiang.gif"),
				networkPanel, "������ս���д�����");
		add(tabbedPane);
	}

	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source == load) {
			ChessLoadingGUI test = new ChessLoadingGUI();
			test.setVisible(true);
		} else if (source == loadAs) {
			JFileChooser fileChooser = new JFileChooser();
			FileNameExtensionFilter filter = new FileNameExtensionFilter(
					EXTENSION_NAME2, EXTENSION_NAME2);
			fileChooser.setFileFilter(filter);

			int state = fileChooser.showOpenDialog(this);
			File openFile = fileChooser.getSelectedFile();
			if (openFile != null && state == JFileChooser.APPROVE_OPTION) {
				// ��ȡ��ǰĿ¼�µ������ļ�

				GameRecord gameRecord = ManualUtil.readManual(openFile);

				ChessDemoGUI demo = new ChessDemoGUI(gameRecord);

				demo.setVisible(true);
				// dispose();

			}
		} else if (source == fen) {

		} else if (source == manMachine) {
			ManMachineGUI ai = new ManMachineGUI();
			ai.setVisible(true);
		} else if (source == partialManual) {
			PrintPartGUI partialManual = new PrintPartGUI();
			partialManual.setVisible(true);

		} else if (source == wholeManual) {
			PrintAllGUI wholeManual = new PrintAllGUI();
			wholeManual.setVisible(true);
		} else if (source == login) {
			check();
		} else if (source == exit) {
			dispose();
		} else if (source == maze) {
			HorseMazeGUI maze = new HorseMazeGUI();
			maze.setVisible(true);
		} else if (source == eightEmpress) {
			EmpressGUI empress = new EmpressGUI();
			empress.setVisible(true);
		} else if (source == fen) {

		}
	}

	/**
	 * ��֤�Ƿ������ӵ�������������ɹ�������ʾ�����棬������ʾ�д���
	 * 
	 */
	private void check() {
		String name = petNameField.getText();
		String host = serverIPField.getText();
		RoomGUI room = new RoomGUI(name);
		System.out.println(host);
		boolean flag = false;

		if (host.equals("")) {
			flag = false;
		} else {
			flag = room.connectToServer(host);
			System.out.println(flag);
		}

		if (flag) {
			this.dispose();
			room.setLocationRelativeTo(null);
			room.setVisible(true);
			room.work();

		} else {
			JOptionPane.showMessageDialog(null, "���ӷ�����ʧ��");
		}
	}

	/**
	 * �ͻ���Ӧ�ó������
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGUI();
			}
		});

	}

	protected static void createAndShowGUI() {
		/* ��������GUI�����ʽ������ϵͳ��ʽ */
		String lookAndFeel = UIManager.getSystemLookAndFeelClassName();
		try {
			UIManager.setLookAndFeel(lookAndFeel);
		} catch (Exception e) {
			e.printStackTrace();
		}

		ChessGUI chineseChess = new ChessGUI();

		chineseChess.setVisible(true);

	}
}
