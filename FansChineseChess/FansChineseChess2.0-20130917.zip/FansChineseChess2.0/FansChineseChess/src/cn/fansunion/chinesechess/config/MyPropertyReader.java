/**
 * ��Ŀ����: FansChineseChess
 * �汾�ţ�2.0
 * ���֣�����
 * ����: http://FansUnion.cn
 * CSDN:http://blog.csdn.net/FansUnion
 * ����: leiwen@FansUnion.cn
 * QQ��240-370-818
 * ��Ȩ����: 2011-2013,leiwen
 */
package cn.fansunion.chinesechess.config;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;

/**
 * �����Լ������Զ�ȡ�ļ�
 * 
 * JDK�Դ���Properties���������ȡISO-8859-1������ַ��������༭���ֲ�����
 * 
 * @author leiwen@fansunion.cn,http://FansUnion.cn,
 *         http://blog.csdn.net/FansUnion
 * @since 2.0
 */
public class MyPropertyReader {
	private HashMap<String, String> properties;

	private String fileName = "";

	public void setFileName(String name) {
		fileName = name;
	}

	public MyPropertyReader() {

	}

	public MyPropertyReader(String fileName) {
		this.fileName = fileName;
		init();
	}

	private void init() {
		properties = new HashMap<String, String>();
		try {
			FileReader reader = new FileReader(new File(fileName));

			String oneLine = "";
			BufferedReader bufferedReader = new BufferedReader(reader);
			while ((oneLine = bufferedReader.readLine()) != null) {
				// System.out.println(oneLine);
				String[] str = oneLine.split("=");
				System.out.println(str.length);
				if (str != null && str.length == 2) {
					// �������trim��ֹǰ�󶼿ո��ַ�
					properties.put(str[0].trim(), str[1].trim());
					// System.out.println("str[0]:" + str[0] + " str[1]:" +
					// str[1]);
				}

			}

			bufferedReader.close();// �ر���

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String get(String key) {
		return properties.get(key);
	}

	public static void main(String[] args) {
		MyPropertyReader reader = new MyPropertyReader("/config/StringConstants.properties");
		String value =reader.get("1");
		System.out.println(value);
	}

	public HashMap<String, String> getProperties() {
		return properties;
	}
}
