/**
 * ��Ŀ����: FansChineseChess
 * �汾�ţ�2.0
 * ���֣�����
 * ����: http://FansUnion.cn
 * CSDN:http://blog.csdn.net/FansUnion
 * ����: leiwen@FansUnion.cn
 * QQ��240-370-818
 * ��Ȩ����: 2011-2013,leiwen
 */
package cn.fansunion.chinesechess.ext.empress;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import cn.fansunion.chinesechess.ChessUtil;
import cn.fansunion.chinesechess.core.ChessPiece;
import cn.fansunion.chinesechess.core.PieceUtil;
import cn.fansunion.chinesechess.core.ChessPiece.PieceId;

/**
 * N�ʺ����
 * 
 * @author ���� 2010/11/26 leiwen@fansunion.cn,http://FansUnion.cn,
 *         http://blog.csdn.net/FansUnion
 * @since 2.0
 */
public class EmpressGUI extends JFrame implements ActionListener, Runnable {

	private static final long serialVersionUID = 266L;

	private JButton prev, next, auto, first, last;

	private JButton save, advancedSave, empress, set, exit, help, undo;

	private JTextField numField = new JTextField(5);

	private EmpressBoard board;// ����

	private JPanel gameStatusPanel;// ��Ϸ״̬���

	private JPanel manualTools;//

	public String tips;

	// ��Ϸ״̬
	private JTextArea gameStatusContent;

	private JScrollPane manualScroll;

	private JList manual = new JList();

	private Vector<String> descs = new Vector<String>();

	private ArrayList<ArrayList<Point>> lists = new ArrayList<ArrayList<Point>>();

	private ArrayList<int[][]> advancedLists = new ArrayList<int[][]>();

	// ��ť���õ�����ͼ��
	private Cursor handCursor = new Cursor(Cursor.HAND_CURSOR);

	private ArrayList<ChessPiece> pieces = new ArrayList<ChessPiece>();

	private Thread autoThread = new Thread(this);

	private int curIndex = -1;

	private TitledBorder recordsBorder;

	/**
	 * ���캯��
	 */
	public EmpressGUI() {

		board = new EmpressBoard();
		// board.owner = this;

		initButtons();
		initPanels();

		// ����ܽ��9�ʺ�����
		for (int index = 0; index < 9; index++) {
			pieces.add(PieceUtil.createPiece(PieceId.SHUAI));
		}

		setSize(660, 620);
		setTitle("�������__��չ��ϰ__N�ʺ����� --����-http://FansUnion.cn");
		setResizable(false);
		setIconImage(ChessUtil.getAppIcon());
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		addWindowListener(new WindowAdapter() {
			// ��ӦĬ�ϵ��˳��¼�
			public void windowClosing(WindowEvent e) {
				handleExitGame();
			}

		});
	}

	/**
	 * ��ʼ�����
	 * 
	 */
	private void initPanels() {
		// �����ұߵ����
		JPanel rightPanel = new JPanel(new BorderLayout());

		// �����������
		JPanel recordsPanel = new JPanel(new BorderLayout());

		recordsBorder = new TitledBorder("���в���");
		recordsPanel.setBorder(recordsBorder);
		recordsPanel.setPreferredSize(new Dimension(240, 330));
		manualScroll = new JScrollPane(manual);
		recordsPanel.add(BorderLayout.CENTER, manualScroll);

		// ������
		manualTools = new JPanel(new FlowLayout(FlowLayout.CENTER));
		// manualTools.setPreferredSize(new Dimension(220, 20));
		manualTools.add(first);
		manualTools.add(prev);
		manualTools.add(auto);
		manualTools.add(next);
		manualTools.add(last);

		recordsPanel.add(BorderLayout.SOUTH, manualTools);

		JPanel controlPanel = new JPanel(new GridLayout(3, 1));

		FlowLayout layout = new FlowLayout(FlowLayout.LEFT);
		JPanel one = new JPanel(layout);
		JPanel two = new JPanel(layout);
		JPanel three = new JPanel(layout);

		one.add(numField);
		one.add(empress);

		two.add(save);
		two.add(advancedSave);
		// two.add(undo);

		three.add(help);
		three.add(set);
		three.add(exit);

		controlPanel.add(one);
		controlPanel.add(two);
		controlPanel.add(three);

		rightPanel.add(BorderLayout.NORTH, recordsPanel);
		rightPanel.add(BorderLayout.CENTER, controlPanel);

		JSplitPane splitH = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, board,
				rightPanel);
		splitH.setDividerSize(5);
		splitH.setDividerLocation(450);
		add(splitH, BorderLayout.CENTER);

		// ��Ϸ״̬���
		gameStatusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		gameStatusPanel.setPreferredSize(new Dimension(660, 90));

		// ��Ϸ״̬��
		gameStatusContent = new JTextArea("  ��N(1<=N<=9)�ʺ�����кϷ�����:\n"
				+ "  3��Լ���������κ�2�����Ӷ�����ռ�������ϵ�ͬһ�С�����ͬһ�С�" + "����ͬһ�Խ���.");
		gameStatusContent.setFont(new Font("����", Font.PLAIN, 16));

		TitledBorder gameStatusBorder = new TitledBorder("��Ϸ״̬");
		gameStatusBorder.setTitleColor(Color.RED);
		gameStatusBorder.setTitleFont(new Font("����", Font.PLAIN, 16));
		gameStatusPanel.setToolTipText("�㷨˵��");
		gameStatusPanel.setBorder(gameStatusBorder);
		gameStatusPanel.add(gameStatusContent);

		add(BorderLayout.SOUTH, gameStatusPanel);

		// �б�����Ӧ������˫���¼�
		manual.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				int count = e.getClickCount();
				// �����¼�
				if (count == 1 || count == 2) {
					int index = manual.getSelectedIndex();
					if (index != -1) {
						curIndex = index;
						displayLayout(curIndex);
					}
				}

			}

		});
	}

	/**
	 * ��ʾ��index������
	 * 
	 * @param index
	 *            ���ֵ�����
	 */
	private void displayLayout(int index) {
		if (index < 0 || index >= lists.size()) {
			return;
		}

		ArrayList<Point> arrayList = lists.get(index);
		int size2 = arrayList.size();
		for (int j = 0; j < size2; j++) {
			Point point = arrayList.get(j);
			ChessPiece piece = pieces.get(j);
			int x = (int) point.getX();
			int y = (int) point.getY();
			board.chessPoints[x][y].setPiece(piece, board);
			validate();
			repaint();
		}
	}

	/**
	 * ��ʼ����ť
	 * 
	 */
	private void initButtons() {
		Dimension iconSize = new Dimension(16, 16);
		prev = new JButton(ChessUtil.getImageIcon("prev.gif"));
		prev.addActionListener(this);
		prev.setToolTipText("��һ������");
		prev.setCursor(new Cursor(Cursor.HAND_CURSOR));
		prev.setPreferredSize(iconSize);

		next = new JButton(ChessUtil.getImageIcon("next.gif"));
		next.addActionListener(this);
		next.setToolTipText("��һ������");
		next.setCursor(new Cursor(Cursor.HAND_CURSOR));
		next.setPreferredSize(iconSize);

		first = new JButton(ChessUtil.getImageIcon("first.gif"));
		first.addActionListener(this);
		first.setToolTipText("��һ������");
		first.setCursor(new Cursor(Cursor.HAND_CURSOR));
		first.setPreferredSize(iconSize);

		last = new JButton(ChessUtil.getImageIcon("last.gif"));
		last.addActionListener(this);
		last.setToolTipText("���һ������");
		last.setCursor(new Cursor(Cursor.HAND_CURSOR));
		last.setPreferredSize(iconSize);

		auto = new JButton(ChessUtil.getImageIcon("auto.gif"));
		auto.addActionListener(this);
		auto.setToolTipText("�Զ���ʾ");
		auto.setPreferredSize(iconSize);
		auto.setCursor(new Cursor(Cursor.HAND_CURSOR));

		Insets insets = new Insets(1, 1, 1, 1);

		advancedSave = new JButton("�߼�����",
				ChessUtil.getImageIcon("reprint.gif"));
		advancedSave.setToolTipText("�߼�����");
		advancedSave.addActionListener(this);
		// reprint.setPreferredSize(dimension);
		advancedSave.setCursor(handCursor);
		advancedSave.setMargin(insets);

		save = new JButton("����", ChessUtil.getImageIcon("save.gif"));
		save.addActionListener(this);
		save.setToolTipText("��������");
		// save.setPreferredSize(dimension);
		save.setCursor(handCursor);
		save.setMargin(insets);

		empress = new JButton("N�ʺ󲼾�", ChessUtil.getImageIcon("saveas.gif"));
		empress.addActionListener(this);
		empress.setToolTipText("N�ʺ󲼾�");
		// saveAs.setPreferredSize(dimension);
		empress.setCursor(handCursor);
		empress.setMargin(insets);

		undo = new JButton("����", ChessUtil.getImageIcon("undo.gif"));
		undo.addActionListener(this);
		undo.setToolTipText("����");
		undo.setCursor(handCursor);
		undo.setMargin(insets);

		set = new JButton("����", ChessUtil.getImageIcon("welcome.gif"));
		set.setToolTipText("����");
		set.addActionListener(this);
		set.setCursor(handCursor);
		set.setMargin(insets);

		help = new JButton("����", ChessUtil.getImageIcon("help.gif"));
		help.setToolTipText("����");
		help.addActionListener(this);
		help.setCursor(handCursor);
		help.setMargin(insets);

		exit = new JButton("�˳�", ChessUtil.getImageIcon("stop.gif"));
		exit.setToolTipText("�˳�");
		exit.addActionListener(this);
		exit.setCursor(handCursor);
		exit.setMargin(insets);

	}

	/**
	 * ��Ӧ�¼�
	 */
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();

		if (source == save) {
			int size = lists.size();
			if (size == 0) {
				JOptionPane.showMessageDialog(this, "û�в��ֿ��Ա��棡");
				return;
			}
			JFileChooser fileChooser = new JFileChooser();
			int state = fileChooser.showSaveDialog(null);
			File saveFile = fileChooser.getSelectedFile();
			if (saveFile != null && state == JFileChooser.APPROVE_OPTION) {
				System.out.println(saveFile.getAbsolutePath());
				// ����
				EmpressUtil.save(saveFile.getAbsolutePath() + ".txt", lists);
			}

		} else if (source == advancedSave) {
			int size = advancedLists.size();
			if (size == 0) {
				JOptionPane.showMessageDialog(this, "û�в��ֿ��Ա��棡");
				return;
			}
			// �߼�����
			// EightEmpressUtil.advancedSave(advancedLists);
			JFileChooser fileChooser = new JFileChooser();
			int state = fileChooser.showSaveDialog(null);
			File saveFile = fileChooser.getSelectedFile();
			if (saveFile != null && state == JFileChooser.APPROVE_OPTION) {
				System.out.println(saveFile.getAbsolutePath());
				// ����
				EmpressUtil.advancedSave(saveFile.getAbsolutePath() + ".txt",
						advancedLists);
			}

		} else if (source == empress) {
			String number = numField.getText();
			int n = 3;
			try {
				n = Integer.valueOf(number);
				if (n < 1 || n > 9) {
					JOptionPane
							.showMessageDialog(this, "��Ǹ��ֻ�����N�ʺ����⣨1<=N<=9��");
					return;
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			EmpressModel ee = new EmpressModel(n);
			ee.initAllLayout();
			lists = ee.getLists();
			advancedLists = ee.getAdvancedLists();
			int size = lists.size();

			descs.clear();
			for (int i = 0; i < size; i++) {
				descs.add("��" + i + "������");
			}
			manual.setListData(descs);

		} else if (source == exit) {
			dispose();
		} else if (source == first) {
			first();
		} else if (source == next) {
			next();
		} else if (source == prev) {
			prev();
		} else if (source == last) {
			last();
		} else if (source == auto) {
			auto();
		}

	}

	/**
	 * 
	 */
	private void auto() {
		if (autoThread == null) {
			autoThread = new Thread(this);
		}
		autoThread.start();
	}

	/**
	 * 
	 */
	private void last() {
		curIndex = lists.size() - 1;
		displayLayout(curIndex);
		scrollToView();
	}

	/**
	 * 
	 */
	private void first() {
		curIndex = 0;
		displayLayout(curIndex);
		scrollToView();
	}

	private void prev() {
		if (curIndex >= 0) {
			displayLayout(curIndex--);
			scrollToView();
		}

	}

	private void next() {
		if (curIndex < lists.size()) {
			displayLayout(curIndex++);
			scrollToView();
		}
	}

	private void handleExitGame() {
		if (board.getWinkThread() != null) {
			board.getWinkThread().interrupt();
			System.out.println("�ر��У�");
		}
		dispose();
	}

	private void scrollToView() {
		if (curIndex >= 0 && curIndex < lists.size()) {
			int lastIndex = curIndex;
			Rectangle rect = manual.getCellBounds(lastIndex, lastIndex);
			manualScroll.getViewport().scrollRectToVisible(rect);
			// ѡ�е�ǰ�У���ʾ���
			manual.setSelectedIndex(curIndex);
			validate();
			repaint();
		}

	}

	/**
	 * ȫ�ִ��ײ��Գ������
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		EmpressGUI empress = new EmpressGUI();
		empress.setVisible(true);
	}

	public void run() {
		while (curIndex >= -1 && curIndex < lists.size()) {
			next();
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		}
	}

}
